Hey there fella! Thanks for downloading this pack I appreciate that!

You can modify all the files at will!

Credit is not required, but very much appreciated!

Something such as:

Sprites used: ThatCoolSprite from https://chocolate4.itch.io/thatcoolsprite.

Have fun with the sprites!